'use strict';

var config = {
    apiKey: "AIzaSyBbaKF-ijGLlCvMJOuF2iUHtSv7B80r8N4",
    authDomain: "contactlist-2392c.firebaseapp.com",
    databaseURL: "https://contactlist-2392c.firebaseio.com",
    storageBucket: "contactlist-2392c.appspot.com",
    messagingSenderId: "74462320695"
  };
  firebase.initializeApp(config);

angular.module('myApp.contacts', ['ngRoute'])

.config(['$routeProvider', function($routeProvider) {
  $routeProvider.when('/', {
    templateUrl: 'contacts/contacts.html',
    controller: 'ContactsCtrl'
  });
}])

.controller('ContactsCtrl', ['$scope','$firebaseArray', function($scope, $firebaseArray) {
	//console.log('Contacts Controller loaded');
	//var firebase = require("firebase/app");
	// require("firebase/auth");
	// require("firebase/database");


	

  var rootRef = firebase.database().ref();
	
	$scope.contacts=$firebaseArray(rootRef);
	$scope.addFormShow=true;
	$scope.editFormShow=false;

	$scope.addContact=function(){
		console.log("Adding contact");

		$scope.contacts.$add({
			name: $scope.name,
			email: $scope.email,
			phone: $scope.phone
		}).then(function(rootRef){
			var id = rootRef.key;
			console.log('Added contact '+id);

			$scope.name = '';
			$scope.email = '';
			$scope.phone = '';

		});
	};

	$scope.editContact = function(){
		var id=$scope.id;
		var record = $scope.contacts.$getRecord(id);
		record.name=$scope.name;
		record.email=$scope.email;
		record.phone=$scope.phone;

		$scope.contacts.$save(record).then(function(rootRef){
			console.log(rootRef.key);
		});

		$scope.name = '';
		$scope.email = '';
		$scope.phone = '';

	}

	$scope.removeContact=function(contact){
		$scope.contacts.$remove(contact);
	};

	$scope.showEditForm=function(contact){
		$scope.addFormShow=false;
		$scope.editFormShow=true;

		$scope.id=contact.$id;
		$scope.name=contact.name;
		$scope.email=contact.email;
		$scope.phone=contact.phone;
	};

}]);